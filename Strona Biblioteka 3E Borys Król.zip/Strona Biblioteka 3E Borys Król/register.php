<?php

$host = 'localhost';
$db = 'biblioteka';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username'], $_POST['email'], $_POST['password'])) {

    $username = htmlspecialchars($_POST['username']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); 


    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo "Użytkownik z takim adresem e-mail już istnieje.";
    } else {
   
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $password);
        $stmt->execute();
        echo "Rejestracja zakończona sukcesem! <a href='login.php'>Zaloguj się</a>";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Rejestracja</title>
</head>
<body>
    <h1>Rejestracja</h1>
    <form method="POST" action="register.php">
        <label for="username">Nazwa użytkownika:</label>
        <input type="text" name="username" id="username" required><br>

        <label for="email">Adres e-mail:</label>
        <input type="email" name="email" id="email" required><br>

        <label for="password">Hasło:</label>
        <input type="password" name="password" id="password" required><br>

        <button type="submit">Zarejestruj się</button>
    </form>
</body>
</html>
