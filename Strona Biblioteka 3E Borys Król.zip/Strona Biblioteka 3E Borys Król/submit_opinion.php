<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['opinia'])) {
    $new_opinia = htmlspecialchars($_POST['opinia']);
    file_put_contents("opinie.txt", $new_opinia . PHP_EOL, FILE_APPEND);
    header("Location: index.php");
    exit();
}
?>
