1.
/*var tab = [5,12,17,23,123,45,54];
console.log(tab); */


2. 
/*var tab = [5,12,17,23,123,45,54];
console.log(tab); */


3.
/*tab = [5,12,17,23,123,45,54];
let output = ' ';
for(let i = 0; i < tab.length; i++) {
    output += tab[i];
    if(i !== tab.lenght) {
        output += ' ,';
    }
}

document.getElementById("tablicaDane").innerHTML = output;*/


4. 
/*const tab = [5,12,17,23,123,45,54];
for(const num of tab) {
    document.getElementById("tablica").innerText += num + ' ';
}*/


5. 
/*const tab = [5,12,17,23,123,45,54];
console.log(tab);
tab.push(2, 201);
console.log(tab);*/


6.
/*const tab = [5,12,17,23,123,45,54];
tab.push(33,44);
console.log("dlugosc: ", tab.length);
console.log("zawartosc: ", tab);*/


7.
/*const tab = [5,12,17,23,123,45,54];
tab.pop();
console.log("Dlugosc: ", tab.length);
console.log("Zawartosc: ", tab);*/


8.
/*const tab = [5,12,17,23,123,45,54];
console.log(tab);
tab.unshift(7,77);
console.log("Dlugosc: ", tab.length);
console.log("Zawartosc: ", tab);*/


9.
/*const tab = [5,12,17,23,123,45,54];
console.log(tab);
tab.shift();
console.log("Dlugosc: ", tab.length);
console.log("Zawartosc: ", tab);*/


10.
/*const tab = [5,12,17,23,123,45,54];
console.log(tab);
tab.reverse();
console.log(tab);*/


11.
/*const tab = [5, 94, 12, 2, 30];
console.log(tab.sort());*/


12.
/*const tab = [5, 94, 12, 2, 30];
tab.forEach((Element, index, Array) => {
    console.log("Element: ", Element);
    console.log("index: ", index);
    console.log("Array: ", Array);
});*/


13.
/*const tab = [5, 94, 12, 2, 30];
tab.forEach((Element, index, Array) => {
    console.log("Element: ", Element);
    console.log("index: ", index);
    console.log("Array: ", Array);
});*/


14.
/*const tab = [5, 94, 12, 2, 30];
tab.forEach((Element, index, Array) => {
    console.log("Element: ", Element);
    console.log("index: ", index);
    console.log("Array: ", Array);
});*/


15.
/*const tab = [5, 94, 12, 2, 30];
tab.forEach((Element, index, Array) => {
    console.log("Element: ", Element);
    console.log("index: ", index);
    console.log("Array: ", Array);
});*/


16.
/*const tab = ["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
tab.reverse();
console.log(tab);*/


17.
/*const tab = ["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
console.log(tab.join(" ,"));
console.log(tab.join( "\n"));*/


18.
/*const tab = ["aaa bbb","aaa bbb","aaa bbb","aaa bbb","aaa bbb","aaa bbb"];
console.log(tab);*/


18.2
/*const tab = ["Fiat","Skoda","Volvo","Mercedes","Kia","Opel","Citroen"];
tab.splice(2,3, "tajne", "tajne");
console.log(tab);*/


19.
/*const tab = ["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
const tab1 = tab.slice(0,2);
console.log(tab);
console.log(tab1);*/


20.
/*const tab = ["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
const tab1 = tab.slice(0,2);
console.log(tab);
console.log(tab1);*/

21. 
/*const tab = ["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
const tab1 = tab.splice(3, 1, "Maria Kapik", "Elzbieta Konf");
console.log("usunieci: ", tab1);
console.log(tab);*/


22.
/*const tab = ["Jan Nowak","Kazimierz Zyga","Stefan Koc","Ewa Mocek","Mariusz Abramski"];
const tab1 = tab.map(name => name.split(' ')[1]).sort();
console.log(tab1);
tab1.forEach(name => console.log(`<h3>${name}</h3>`));*/