<?php
session_start();


$host = 'localhost';
$db = 'biblioteka';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if(!isset($_COOKIE['visited'])) {
    setcookie('visited', '1', time() + (86400 * 30), "/"); // 30 dni
    $cookie_message = "Witaj na naszej stronie!";
} else {
    $cookie_message = "Witaj ponownie!";
}


$opinie = [
    "Świetna strona! Bardzo mi się podoba.",
    "Interesujące treści, chętnie wrócę.",
    "Znalazłem to, czego szukałem. Polecam!"
];
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteka Internetowa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  
    <header>
        <h1>Biblioteka Internetowa</h1>
        <?php if (isset($_SESSION['username'])): ?>
            <p>Witaj, <?php echo htmlspecialchars($_SESSION['username']); ?>! <a href="logout.php">Wyloguj się</a></p>
        <?php else: ?>
            <p>Nie jesteś zalogowany. <a href="login.php">Zaloguj się</a> lub <a href="register.php">Zarejestruj się</a></p>
        <?php endif; ?>
    </header>

 
    <div id="cookieMessage">
        <p><?php echo $cookie_message; ?> Używamy plików cookie w celu poprawy jakości usług. <a href="#">Dowiedz się więcej</a></p>
    </div>

   
    <section id="opinie">
        <h2>Opinie użytkowników:</h2>
        <ul>
            <?php
            foreach($opinie as $opinia) {
                echo "<li>" . htmlspecialchars($opinia) . "</li>";
            }
            ?>
        </ul>
        <h3>Dodaj swoją opinię:</h3>
        <form action="submit_opinion.php" method="POST">
            <textarea name="opinia" placeholder="Napisz swoją opinię..." required></textarea>
            <button type="submit">Wyślij opinię</button>
        </form>
    </section>


    <footer>
        <p>&copy; 2025 Borys Król Biblioteka Internetowa</p>
    </footer>
</body>
</html>
